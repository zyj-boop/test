import torch
import torch.nn as nn
from torch.autograd import Variable as V

import cv2
import numpy as np

class MyFrame_bound():
    def __init__(self, net, loss, lr=2e-4, evalmode = False):
        self.net = net().cuda()
        self.net = torch.nn.DataParallel(self.net, device_ids=range(torch.cuda.device_count()))
        self.optimizer = torch.optim.Adam(params=self.net.parameters(), lr=lr)
        self.loss = loss()
        self.old_lr = lr
        if evalmode:
            for i in self.net.modules():
                if isinstance(i, nn.BatchNorm2d):
                    i.eval()


    def set_input(self, img_batch, mask_batch=None, mask_bound_batch=None, img_id=None):
        self.img = img_batch
        self.mask = mask_batch
        self.mask_bound = mask_bound_batch
        self.img_id = img_id
        
    def test_one_img(self, img):
        pred = self.net.forward(img)
        
        pred[pred>0.5] = 1
        pred[pred<=0.5] = 0

        mask = pred.squeeze().cpu().data.numpy()
        return mask
    
    def test_batch(self):
        self.forward(volatile=True)
        mask =  self.net.forward(self.img).cpu().data.numpy().squeeze(1)
        mask[mask>0.5] = 1
        mask[mask<=0.5] = 0
        
        return mask, self.img_id
    
    def test_one_img_from_path(self, path):
        img = cv2.imread(path)
        img = np.array(img, np.float32)/255.0 * 3.2 - 1.6
        img = V(torch.Tensor(img).cuda())
        
        mask = self.net.forward(img).squeeze().cpu().data.numpy()
        mask[mask>0.5] = 1
        mask[mask<=0.5] = 0
        
        return mask




    def forward(self, volatile=False):
        #表示转换到GPU模式下
        self.img = V(self.img.cuda(), volatile=volatile)  #volatile等于FALSE表示会求导
        if self.mask is not None:
            self.mask = V(self.mask.cuda(), volatile=volatile)
        if self.mask_bound is not None:
            self.mask_bound = V(self.mask_bound.cuda(), volatile=volatile)
        
    def optimize(self):
        self.forward()
        self.optimizer.zero_grad() #清空过往梯度
        pred , pred_bound = self.net.forward(self.img) #利用搭建的网络对输入的影像数据进行一系列编码和解码，生成1*1024*1024的预测结果
        #pred= self.net.forward(self.img)
        boat_loss = self.loss(self.mask, pred)  #计算预测值和标签值（mask，真实值）之间的差距
        #loss = self.loss(self.mask, pred)
        bound_loss = self.loss(self.mask_bound, pred_bound)
        loss = boat_loss + bound_loss
        loss.backward() #反向传播，计算当前梯度；
        self.optimizer.step()# 根据梯度更新网络参数
        return loss.item()
        
    def save(self, path):
        torch.save(self.net.state_dict(), path)  #输出网络参数
        
    def load(self, path):
        self.net.load_state_dict(torch.load(path))
    
    def update_lr(self, new_lr, mylog, factor=False):
        if factor:
            new_lr = self.old_lr / new_lr
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = new_lr

        print('update learning rate: %f -> %f' % (self.old_lr, new_lr), file=mylog)
        #print >> mylog, 'update learning rate: %f -> %f' % (self.old_lr, new_lr)
        print('update learning rate: %f -> %f' % (self.old_lr, new_lr))
        self.old_lr = new_lr
