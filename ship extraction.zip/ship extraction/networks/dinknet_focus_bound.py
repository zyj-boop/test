import math
from torchvision import models
from torch.nn import Module,  Parameter, Softmax
from functools import partial
import torch
import torch.nn as nn
import torch.nn.functional as F
nonlinearity = partial(F.relu, inplace=True)


class KAM_Module(nn.Module):
    def __init__(self, input_dim, num_heads=8, dropout_rate=0.1):
        super(KAM_Module, self).__init__()

        self.input_dim = input_dim
        self.num_heads = num_heads

        assert input_dim % num_heads == 0, "The input dimension should be divisible by the number of heads."

        self.head_dim = input_dim // num_heads

        self.qkv_transform = nn.Linear(input_dim, 3 * input_dim)

        self.out_projection = nn.Linear(input_dim, input_dim)

        self.dropout = nn.Dropout(dropout_rate)
        self.softmax = nn.Softmax(dim=-3)

    def forward(self, x):
        batch_size, channels, width, height = x.size()

        assert channels == self.input_dim, f"The second dimension of the input tensor x should be {self.input_dim}."

        flat_x = x.reshape(-1, self.input_dim)

        qkv = self.qkv_transform(flat_x).view(batch_size, width, height, self.num_heads, self.head_dim * 3).transpose(1, 2)

        queries, keys, values = qkv.chunk(3, dim=-1)

        scores = torch.matmul(queries, keys.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attention_weights = self.softmax(scores)

        attention_weights = self.dropout(attention_weights)

        attended_values = torch.matmul(attention_weights, values)

        attended_values = attended_values.transpose(1, 2).contiguous().view(batch_size * width * height, self.input_dim)
        output = self.out_projection(attended_values)

        output = output.view(batch_size, self.input_dim, width, height)

        return output

class CAM_Module(Module):
    def __init__(self):
        super(CAM_Module, self).__init__()
        self.gamma = Parameter(torch.zeros(1))
        self.softmax = Softmax(dim=-1)

    def forward(self, x):
        batch_size, chnnels, width, height = x.shape
        proj_query = x.view(batch_size, chnnels, -1)
        proj_key = x.view(batch_size, chnnels, -1).permute(0, 2, 1)
        energy = torch.bmm(proj_query, proj_key)
        energy_new = torch.max(energy, -1, keepdim=True)[0].expand_as(energy) - energy
        attention = self.softmax(energy_new)
        proj_value = x.view(batch_size, chnnels, -1)

        out = torch.bmm(attention, proj_value)
        out = out.view(batch_size, chnnels, height, width)

        out = self.gamma * out + x
        return out

class KAM_CAM_Layer(nn.Module):
    def __init__(self, in_ch):
        super(KAM_CAM_Layer, self).__init__()
        self.KAM = KAM_Module(in_ch)
        self.CAM = CAM_Module()

    def forward(self, x):
        return self.KAM(x) + self.CAM(x)

class DecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters):
        super(DecoderBlock,self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1) #output_padding一般取stride-1，这样就使得输出后的图像是输入的stride倍
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.conv3 = nn.Conv2d(in_channels // 4, n_filters, 1)
        self.norm3 = nn.BatchNorm2d(n_filters)
        self.relu3 = nonlinearity

    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x = self.conv3(x)
        x = self.norm3(x)
        x = self.relu3(x)
        return x

class DinkNet34_focus_bound(nn.Module):
    def __init__(self, num_classes=1, num_channels=3):
        super(DinkNet34_focus_bound, self).__init__()

        filters = [64, 128, 256, 512]
        resnet = models.resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4

        self.attention4 = KAM_CAM_Layer(filters[3])
        self.attention3 = KAM_CAM_Layer(filters[2])
        self.attention2 = KAM_CAM_Layer(filters[1])
        self.attention1 = KAM_CAM_Layer(filters[0])


        self.decoder4 = DecoderBlock(filters[3], filters[2])
        self.decoder3 = DecoderBlock(filters[2], filters[1])
        self.decoder2 = DecoderBlock(filters[1], filters[0])
        self.decoder1 = DecoderBlock(filters[0], filters[0])

        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)


    def forward(self, x):
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x = self.firstmaxpool(x)
        e1 = self.encoder1(x)
        e2 = self.encoder2(e1)
        e3 = self.encoder3(e2)
        e4 = self.encoder4(e3)
        # bound
        c4 = self.decoder4(e4) + e3
        c3 = self.decoder3(c4) + e2
        c2 = self.decoder2(c3) + e1
        c1 = self.decoder1(c2)

        e4 = self.attention4(e4)
        # Decoder
        d4 = self.decoder4(e4)
        d3 = self.decoder3(d4 + self.attention3(e3))
        d2 = self.decoder2(d3 + self.attention2(e2))
        d1 = self.decoder1(d2 + self.attention1(e1))

        out = self.finaldeconv1(d1)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)

        outb = self.finaldeconv1(c1)
        outb = self.finalrelu1(outb)
        outb = self.finalconv2(outb)
        outb = self.finalrelu2(outb)
        outb = self.finalconv3(outb)
        #轮廓机制
        return F.sigmoid(out),  F.sigmoid(outb)


